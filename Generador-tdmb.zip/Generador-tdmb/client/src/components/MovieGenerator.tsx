import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CodeDisplay } from './CodeDisplay';
import { MoviePreview } from './MoviePreview';
import { Loader2, Wand2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { MovieData, GenerateMovieHtmlResponse } from '@shared/schema';

export function MovieGenerator() {
  const [movieId, setMovieId] = useState('');
  const [movieUrl, setMovieUrl] = useState('');
  const [manualTrailerUrl, setManualTrailerUrl] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [movieData, setMovieData] = useState<MovieData | null>(null);
  const [trailerUrl, setTrailerUrl] = useState('');
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { movieId: string; movieUrl: string; trailerUrl?: string }) => {
      const response = await apiRequest('POST', '/api/movie/generate', data);
      return (await response.json()) as GenerateMovieHtmlResponse;
    },
    onSuccess: (data) => {
      if (data.error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: data.error,
        });
        setMovieData(null);
        setGeneratedCode('');
      } else if (data.html && data.movieData) {
        setGeneratedCode(data.html);
        setMovieData(data.movieData);
        setTrailerUrl(data.trailerUrl || '');
      }
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message || 'Error al generar el código',
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!movieUrl.trim()) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Debes agregar la URL de la película',
      });
      return;
    }

    setGeneratedCode('');
    setMovieData(null);
    setTrailerUrl('');

    generateMutation.mutate({
      movieId,
      movieUrl,
      trailerUrl: manualTrailerUrl.trim() || undefined,
    });
  };

  return (
    <div className="mt-4 sm:mt-6 md:mt-8 grid gap-4 sm:gap-6 md:gap-8 lg:grid-cols-2">
      <Card data-testid="card-configuration">
        <CardHeader>
          <CardTitle className="font-headline">Configuración de Película</CardTitle>
          <CardDescription>
            Proporciona el ID de la película de TMDB y la URL del reproductor.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="movieId" className="font-medium">
                TMDB Movie ID
              </Label>
              <Input
                id="movieId"
                placeholder="e.g., 550 (Fight Club)"
                value={movieId}
                onChange={(e) => setMovieId(e.target.value)}
                required
                data-testid="input-movie-id"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="movieUrl" className="font-medium">
                URL del Reproductor
              </Label>
              <Input
                id="movieUrl"
                placeholder="https://..."
                value={movieUrl}
                onChange={(e) => setMovieUrl(e.target.value)}
                required
                data-testid="input-movie-url"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="trailerUrl" className="font-medium">
                URL del Tráiler (Opcional)
              </Label>
              <Input
                id="trailerUrl"
                placeholder="https://www.youtube.com/embed/... (opcional)"
                value={manualTrailerUrl}
                onChange={(e) => setManualTrailerUrl(e.target.value)}
                data-testid="input-trailer-url"
              />
              <p className="text-sm text-muted-foreground">
                Si no se proporciona, se usará el tráiler de TMDB (si está disponible)
              </p>
            </div>

            <Button
              type="submit"
              className="w-full mt-6"
              disabled={generateMutation.isPending}
              data-testid="button-generate"
            >
              {generateMutation.isPending ? <Loader2 className="animate-spin" /> : <Wand2 />}
              Generar Código
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-6 md:space-y-8">
        <div>
          <h2 className="text-xl sm:text-2xl font-headline font-bold mb-3 md:mb-4">
            Vista Previa en Vivo
          </h2>
          <div className="rounded-lg border bg-card text-card-foreground shadow-sm min-h-[300px] sm:min-h-[400px]">
            {generateMutation.isPending && (
              <div className="p-8 text-center text-muted-foreground flex items-center justify-center h-full">
                <Loader2 className="animate-spin h-8 w-8" />
              </div>
            )}
            {!generateMutation.isPending && !movieData && (
              <div className="p-8 text-center text-muted-foreground flex items-center justify-center h-full">
                La vista previa aparecerá aquí.
              </div>
            )}
            {movieData && (
              <MoviePreview
                movie={movieData}
                trailerUrl={trailerUrl}
                movieUrl={movieUrl}
              />
            )}
          </div>
        </div>

        {generatedCode && (
          <div>
            <h2 className="text-xl sm:text-2xl font-headline font-bold mb-3 md:mb-4">
              HTML Generado
            </h2>
            <CodeDisplay code={generatedCode} />
          </div>
        )}
      </div>
    </div>
  );
}
