import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { PlayCircle } from 'lucide-react';
import { StarRating } from './StarRating';
import { VideoPlayer } from './VideoPlayer';
import type { MovieData } from '@shared/schema';

interface MoviePreviewProps {
  movie: MovieData;
  trailerUrl: string;
  movieUrl: string;
}

export function MoviePreview({ movie, trailerUrl, movieUrl }: MoviePreviewProps) {
  const [isTrailerOpen, setTrailerOpen] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const playerRef = useRef<HTMLDivElement>(null);

  const handlePlay = () => {
    setShowPlayer(true);
    setTimeout(() => {
      if (playerRef.current) {
        playerRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  const openTrailer = () => {
    if (trailerUrl) {
      setTrailerOpen(true);
    }
  };

  const onTrailerOpenChange = (open: boolean) => {
    if (!open) {
      setTrailerOpen(false);
    }
  };

  return (
    <div
      className="bg-black/80 bg-blend-darken bg-cover bg-center relative text-white rounded-lg overflow-hidden h-full flex flex-col"
      style={{
        backgroundImage: `linear-gradient(to right, rgba(0, 0, 0, 0.85) 0%, rgba(0, 0, 0, 0.5) 50%, rgba(0, 0, 0, 0.85) 100%), url(${movie.backdropUrl})`,
      }}
      data-testid="movie-preview"
    >
      <div className="flex flex-col md:flex-row gap-6 lg:gap-8 w-full p-4 sm:p-6 lg:p-8 flex-grow justify-center items-center md:items-start">
        <div className="w-full sm:w-64 md:w-[240px] lg:w-[280px] flex-shrink-0 mx-auto md:mx-0">
          <img
            src={movie.posterUrl}
            alt={`Póster de ${movie.title}`}
            className="rounded-lg shadow-2xl w-full object-cover"
            data-testid="img-poster"
          />
        </div>
        <div className="flex-1 w-full max-w-2xl">
          <h1
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black uppercase tracking-wide font-headline mb-3 md:mb-4"
            data-testid="text-movie-title"
          >
            {movie.title}
          </h1>
          <div className="my-3 md:my-4 flex flex-wrap items-center gap-3 md:gap-4 text-xs sm:text-sm">
            <div className="flex items-center gap-2">
              <StarRating rating={movie.rating} />
              <span className="font-bold text-yellow-400" data-testid="text-rating">
                {movie.rating.toFixed(1)}
              </span>
            </div>
            <span
              className="font-bold bg-gray-700/50 px-2.5 md:px-3 py-1 rounded-full text-xs sm:text-sm"
              data-testid="text-year"
            >
              {movie.year}
            </span>
            <span className="text-gray-300 text-xs sm:text-sm" data-testid="text-genres">
              {movie.genres}
            </span>
          </div>
          <p className="text-sm sm:text-base leading-relaxed text-gray-200 mb-4 md:mb-6" data-testid="text-synopsis">
            {movie.synopsis}
          </p>

          <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 md:gap-4">
            <Button
              onClick={handlePlay}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 font-bold w-full sm:w-auto"
              data-testid="button-play-now"
            >
              <PlayCircle className="mr-2 h-5 w-5" /> VER AHORA
            </Button>
            {trailerUrl && (
              <Button
                onClick={openTrailer}
                size="lg"
                variant="destructive"
                className="font-bold w-full sm:w-auto"
                data-testid="button-trailer"
              >
                <PlayCircle className="mr-2 h-5 w-5" /> TRÁILER
              </Button>
            )}
          </div>
        </div>
      </div>

      {showPlayer && (
        <div className="bg-black/70 backdrop-blur-sm p-3 sm:p-4 md:p-6" ref={playerRef}>
          <div className="max-w-4xl mx-auto">
            {movieUrl ? (
              <VideoPlayer url={movieUrl} season={0} episode={0} />
            ) : (
              <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
                <p className="text-muted-foreground text-sm">
                  No hay URL de reproductor disponible
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      <Dialog open={isTrailerOpen} onOpenChange={onTrailerOpenChange}>
        <DialogContent className="max-w-4xl h-auto p-0 bg-black border-0" data-testid="dialog-trailer">
          <DialogTitle className="sr-only">Tráiler de {movie.title}</DialogTitle>
          {trailerUrl && (
            <div className="aspect-video">
              <iframe
                src={trailerUrl}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={`Tráiler de ${movie.title}`}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
