import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { CodeDisplay } from './CodeDisplay';
import { SeriesPreview } from './SeriesPreview';
import { Loader2, Wand2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type {
  SeriesData,
  SeasonData,
  EpisodeUrl,
  GetSeasonsResponse,
  GenerateSeriesHtmlResponse,
} from '@shared/schema';

interface SeriesGeneratorProps {
  isAnime?: boolean;
}

export function SeriesGenerator({ isAnime = false }: SeriesGeneratorProps) {
  const [seriesId, setSeriesId] = useState('');
  const [episodeUrls, setEpisodeUrls] = useState<EpisodeUrl[]>([]);
  const [manualTrailerUrl, setManualTrailerUrl] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [seriesData, setSeriesData] = useState<SeriesData | null>(null);
  const [seasons, setSeasons] = useState<SeasonData[]>([]);
  const [trailerUrl, setTrailerUrl] = useState('');
  const { toast } = useToast();

  const {
    data: seasonsData,
    isLoading: loadingSeasons,
    error: seasonsError,
  } = useQuery<GetSeasonsResponse>({
    queryKey: [`/api/series/seasons/${seriesId}`],
    enabled: seriesId.length > 3,
    refetchOnWindowFocus: false,
    retry: false,
  });

  useEffect(() => {
    if (seasonsData?.seasons) {
      setSeasons(seasonsData.seasons);
      const newEpisodeUrls: EpisodeUrl[] = [];
      seasonsData.seasons.forEach((season) => {
        for (let i = 1; i <= season.episode_count; i++) {
          newEpisodeUrls.push({ season: season.season_number, episode: i, url: '' });
        }
      });
      setEpisodeUrls(newEpisodeUrls);
    } else if (seasonsData?.error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: seasonsData.error,
      });
      setSeasons([]);
      setEpisodeUrls([]);
    } else if (seriesId.length <= 3) {
      setSeasons([]);
      setEpisodeUrls([]);
    }
  }, [seasonsData, toast, seriesId]);

  useEffect(() => {
    if (seasonsError) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Error al cargar las temporadas',
      });
    }
  }, [seasonsError, toast]);

  const generateMutation = useMutation({
    mutationFn: async (data: { seriesId: string; episodes: EpisodeUrl[]; trailerUrl?: string }) => {
      const response = await apiRequest(
        'POST',
        '/api/series/generate',
        data
      );
      return await response.json() as GenerateSeriesHtmlResponse;
    },
    onSuccess: (data) => {
      if (data.error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: data.error,
        });
        setSeriesData(null);
        setGeneratedCode('');
      } else if (data.html && data.seriesData && data.seasons) {
        setGeneratedCode(data.html);
        setSeriesData(data.seriesData);
        setSeasons(data.seasons);
        setTrailerUrl(data.trailerUrl || '');
      }
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message || 'Error al generar el código',
      });
    },
  });

  const handleEpisodeUrlChange = (season: number, episode: number, url: string) => {
    setEpisodeUrls((prev) =>
      prev.map((ep) =>
        ep.season === season && ep.episode === episode ? { ...ep, url } : ep
      )
    );
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setGeneratedCode('');
    setSeriesData(null);
    setTrailerUrl('');

    const validEpisodes = episodeUrls.filter((ep) => ep.url.trim() !== '');
    
    if (validEpisodes.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Debes agregar al menos una URL de episodio',
      });
      return;
    }

    generateMutation.mutate({
      seriesId,
      episodes: validEpisodes,
      trailerUrl: manualTrailerUrl.trim() || undefined,
    });
  };

  return (
    <div className="mt-4 sm:mt-6 md:mt-8 grid gap-4 sm:gap-6 md:gap-8 lg:grid-cols-2">
      <Card data-testid="card-configuration">
        <CardHeader>
          <CardTitle className="font-headline">
            Configuración de {isAnime ? 'Anime' : 'Serie'}
          </CardTitle>
          <CardDescription>
            Proporciona el ID de {isAnime ? 'la serie de anime' : 'la serie'} de TMDB y las URLs de episodios.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="seriesId" className="font-medium">
                TMDB Series ID
              </Label>
              <Input
                id="seriesId"
                placeholder="e.g., 1399"
                value={seriesId}
                onChange={(e) => setSeriesId(e.target.value)}
                required
                data-testid="input-series-id"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-medium">Episodios</Label>
              {loadingSeasons && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="animate-spin h-4 w-4" />
                  Cargando temporadas...
                </div>
              )}
              {seasons.length > 0 ? (
                <Accordion type="multiple" className="w-full">
                  {seasons.map((season) => (
                    <AccordionItem
                      value={`season-${season.season_number}`}
                      key={season.season_number}
                      data-testid={`accordion-season-${season.season_number}`}
                    >
                      <AccordionTrigger>Temporada {season.season_number}</AccordionTrigger>
                      <AccordionContent className="space-y-3 pl-2 max-h-60 overflow-y-auto">
                        {Array.from({ length: season.episode_count }, (_, i) => i + 1).map(
                          (episodeNum) => (
                            <div key={episodeNum} className="flex items-center gap-2">
                              <Label
                                htmlFor={`s${season.season_number}e${episodeNum}`}
                                className="flex-shrink-0 w-20 text-sm"
                              >
                                Ep. {episodeNum}
                              </Label>
                              <Input
                                id={`s${season.season_number}e${episodeNum}`}
                                placeholder="https://..."
                                value={
                                  episodeUrls.find(
                                    (ep) =>
                                      ep.season === season.season_number &&
                                      ep.episode === episodeNum
                                  )?.url || ''
                                }
                                onChange={(e) =>
                                  handleEpisodeUrlChange(
                                    season.season_number,
                                    episodeNum,
                                    e.target.value
                                  )
                                }
                                data-testid={`input-episode-s${season.season_number}e${episodeNum}`}
                              />
                            </div>
                          )
                        )}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              ) : !loadingSeasons && seriesId ? (
                <div className="text-sm text-muted-foreground">
                  No se encontraron temporadas para este ID.
                </div>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor="trailerUrl" className="font-medium">
                URL del Tráiler (Opcional)
              </Label>
              <Input
                id="trailerUrl"
                placeholder="https://www.youtube.com/embed/... (opcional)"
                value={manualTrailerUrl}
                onChange={(e) => setManualTrailerUrl(e.target.value)}
                data-testid="input-trailer-url"
              />
              <p className="text-sm text-muted-foreground">
                Si no se proporciona, se usará el tráiler de TMDB (si está disponible)
              </p>
            </div>

            <Button
              type="submit"
              className="w-full mt-6"
              disabled={generateMutation.isPending || seasons.length === 0}
              data-testid="button-generate"
            >
              {generateMutation.isPending ? (
                <Loader2 className="animate-spin" />
              ) : (
                <Wand2 />
              )}
              Generar Código
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-6 md:space-y-8">
        <div>
          <h2 className="text-xl sm:text-2xl font-headline font-bold mb-3 md:mb-4">Vista Previa en Vivo</h2>
          <div className="rounded-lg border bg-card text-card-foreground shadow-sm min-h-[300px] sm:min-h-[400px]">
            {generateMutation.isPending && (
              <div className="p-8 text-center text-muted-foreground flex items-center justify-center h-full">
                <Loader2 className="animate-spin h-8 w-8" />
              </div>
            )}
            {!generateMutation.isPending && !seriesData && (
              <div className="p-8 text-center text-muted-foreground flex items-center justify-center h-full">
                La vista previa aparecerá aquí.
              </div>
            )}
            {seriesData && seasons.length > 0 && (
              <SeriesPreview
                series={seriesData}
                seasons={seasons}
                trailerUrl={trailerUrl}
                episodes={episodeUrls}
              />
            )}
          </div>
        </div>

        {generatedCode && (
          <div>
            <h2 className="text-xl sm:text-2xl font-headline font-bold mb-3 md:mb-4">HTML Generado</h2>
            <CodeDisplay code={generatedCode} />
          </div>
        )}
      </div>
    </div>
  );
}
