import { useState, useMemo, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { PlayCircle } from 'lucide-react';
import { StarRating } from './StarRating';
import { VideoPlayer } from './VideoPlayer';
import type { SeriesData, SeasonData, EpisodeUrl } from '@shared/schema';

interface SeriesPreviewProps {
  series: SeriesData;
  seasons: SeasonData[];
  trailerUrl: string;
  episodes: EpisodeUrl[];
}

export function SeriesPreview({ series, trailerUrl, seasons, episodes }: SeriesPreviewProps) {
  const [isTrailerOpen, setTrailerOpen] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const playerRef = useRef<HTMLDivElement>(null);

  const validEpisodes = useMemo(
    () => episodes.filter((e) => e.url && e.url.trim() !== ''),
    [episodes]
  );

  const availableSeasons = useMemo(
    () =>
      Array.from(new Set(validEpisodes.map((e) => e.season)))
        .map((seasonNum) => seasons.find((s) => s.season_number === seasonNum))
        .filter((s): s is SeasonData => s !== undefined)
        .sort((a, b) => a.season_number - b.season_number),
    [seasons, validEpisodes]
  );

  const [selectedSeason, setSelectedSeason] = useState<number | undefined>(undefined);
  const [selectedEpisode, setSelectedEpisode] = useState<number | undefined>(undefined);

  const episodesInSeason = useMemo(() => {
    if (selectedSeason === undefined) return [];
    return validEpisodes
      .filter((e) => e.season === selectedSeason)
      .sort((a, b) => a.episode - b.episode);
  }, [selectedSeason, validEpisodes]);

  const currentEpisodeUrl = useMemo(() => {
    return validEpisodes.find(
      (e) => e.season === selectedSeason && e.episode === selectedEpisode
    )?.url;
  }, [validEpisodes, selectedSeason, selectedEpisode]);

  useEffect(() => {
    if (availableSeasons.length > 0 && selectedSeason === undefined) {
      const firstSeason = availableSeasons[0].season_number;
      setSelectedSeason(firstSeason);
      const firstSeasonEpisodes = validEpisodes
        .filter((e) => e.season === firstSeason)
        .sort((a, b) => a.episode - b.episode);
      if (firstSeasonEpisodes.length > 0) {
        setSelectedEpisode(firstSeasonEpisodes[0].episode);
      }
    }
  }, [availableSeasons, validEpisodes, selectedSeason]);

  const handleSeasonChange = (val: string) => {
    const newSeasonNumber = Number(val);
    setSelectedSeason(newSeasonNumber);
    const newEpisodes = validEpisodes
      .filter((e) => e.season === newSeasonNumber)
      .sort((a, b) => a.episode - b.episode);
    const firstEpisode = newEpisodes[0];
    setSelectedEpisode(firstEpisode?.episode);
  };

  const handleEpisodeChange = (val: string) => {
    const newEpisodeNumber = Number(val);
    setSelectedEpisode(newEpisodeNumber);
  };

  const handlePlay = () => {
    setShowPlayer(true);
    setTimeout(() => {
      if (playerRef.current) {
        playerRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  const openTrailer = () => {
    if (trailerUrl) {
      setTrailerOpen(true);
    }
  };

  const onTrailerOpenChange = (open: boolean) => {
    if (!open) {
      setTrailerOpen(false);
    }
  };

  return (
    <div
      className="bg-black/80 bg-blend-darken bg-cover bg-center relative text-white rounded-lg overflow-hidden h-full flex flex-col"
      style={{
        backgroundImage: `linear-gradient(to right, rgba(0, 0, 0, 0.85) 0%, rgba(0, 0, 0, 0.5) 50%, rgba(0, 0, 0, 0.85) 100%), url(${series.backdropUrl})`,
      }}
      data-testid="series-preview"
    >
      <div className="flex flex-col md:flex-row gap-6 lg:gap-8 w-full p-4 sm:p-6 lg:p-8 flex-grow justify-center items-center md:items-start">
        <div className="w-full sm:w-64 md:w-[240px] lg:w-[280px] flex-shrink-0 mx-auto md:mx-0">
          <img
            src={series.posterUrl}
            alt={`Póster de ${series.title}`}
            className="rounded-lg shadow-2xl w-full object-cover"
            data-testid="img-poster"
          />
        </div>
        <div className="flex-1 w-full max-w-2xl">
          <h1
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black uppercase tracking-wide font-headline mb-3 md:mb-4"
            data-testid="text-series-title"
          >
            {series.title}
          </h1>
          <div className="my-3 md:my-4 flex flex-wrap items-center gap-3 md:gap-4 text-xs sm:text-sm">
            <div className="flex items-center gap-2">
              <StarRating rating={series.rating} />
              <span className="font-bold text-yellow-400" data-testid="text-rating">
                {series.rating.toFixed(1)}
              </span>
            </div>
            <span
              className="font-bold bg-gray-700/50 px-2.5 md:px-3 py-1 rounded-full text-xs sm:text-sm"
              data-testid="text-year"
            >
              {series.year}
            </span>
            <span className="text-gray-300 text-xs sm:text-sm" data-testid="text-genres">
              {series.genres}
            </span>
          </div>
          <p className="text-sm sm:text-base leading-relaxed text-gray-200 mb-4 md:mb-6" data-testid="text-synopsis">
            {series.synopsis}
          </p>

          <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 md:gap-4">
            {validEpisodes.length > 0 && (
              <Button
                onClick={handlePlay}
                size="lg"
                className="bg-white text-black hover:bg-gray-200 font-bold w-full sm:w-auto"
                disabled={!currentEpisodeUrl}
                data-testid="button-play-now"
              >
                <PlayCircle className="mr-2 h-5 w-5" /> VER AHORA
              </Button>
            )}
            {trailerUrl && (
              <Button
                onClick={openTrailer}
                size="lg"
                variant="destructive"
                className="font-bold w-full sm:w-auto"
                data-testid="button-trailer"
              >
                <PlayCircle className="mr-2 h-5 w-5" /> TRÁILER
              </Button>
            )}
          </div>
        </div>
      </div>

      {validEpisodes.length > 0 && showPlayer && (
        <div className="bg-black/70 backdrop-blur-sm p-3 sm:p-4 md:p-6" ref={playerRef}>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 md:gap-4 w-full max-w-4xl mx-auto mb-3 md:mb-4">
            <div className="flex-1 w-full space-y-2">
              <Label htmlFor="season-select" className="text-white text-sm font-medium">
                Temporada
              </Label>
              <Select
                value={selectedSeason !== undefined ? String(selectedSeason) : ''}
                onValueChange={handleSeasonChange}
                disabled={availableSeasons.length === 0}
              >
                <SelectTrigger
                  id="season-select"
                  className="w-full bg-neutral-800 border-neutral-700 text-white font-medium h-11"
                  data-testid="select-season"
                >
                  <SelectValue placeholder="Seleccionar temporada" />
                </SelectTrigger>
                <SelectContent>
                  {availableSeasons.map((s) => (
                    <SelectItem
                      key={s.season_number}
                      value={String(s.season_number)}
                      data-testid={`select-season-${s.season_number}`}
                    >
                      Temporada {s.season_number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 w-full space-y-2">
              <Label htmlFor="episode-select" className="text-white text-sm font-medium">
                Episodio
              </Label>
              <Select
                value={selectedEpisode !== undefined ? String(selectedEpisode) : ''}
                onValueChange={handleEpisodeChange}
                disabled={episodesInSeason.length === 0}
              >
                <SelectTrigger
                  id="episode-select"
                  className="w-full bg-neutral-800 border-neutral-700 text-white h-11"
                  data-testid="select-episode"
                >
                  <SelectValue placeholder="Seleccionar episodio" />
                </SelectTrigger>
                <SelectContent>
                  {episodesInSeason.map((e) => (
                    <SelectItem
                      key={e.episode}
                      value={String(e.episode)}
                      data-testid={`select-episode-${e.episode}`}
                    >
                      Episodio {e.episode}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="max-w-4xl mx-auto">
            {currentEpisodeUrl && selectedSeason && selectedEpisode ? (
              <VideoPlayer
                url={currentEpisodeUrl}
                season={selectedSeason}
                episode={selectedEpisode}
              />
            ) : (
              <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
                <p className="text-muted-foreground text-sm">
                  Seleccione un episodio para reproducir
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      <Dialog open={isTrailerOpen} onOpenChange={onTrailerOpenChange}>
        <DialogContent className="max-w-4xl h-auto p-0 bg-black border-0" data-testid="dialog-trailer">
          <DialogTitle className="sr-only">Tráiler de {series.title}</DialogTitle>
          {trailerUrl && (
            <div className="aspect-video">
              <iframe
                src={trailerUrl}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={`Tráiler de ${series.title}`}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
