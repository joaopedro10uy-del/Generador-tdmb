import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
}

export function StarRating({ rating }: StarRatingProps) {
  const totalStars = 5;
  const filledStars = Math.round(rating / 2);

  return (
    <div className="flex items-center gap-1 text-yellow-400" data-testid="star-rating">
      {Array.from({ length: filledStars }, (_, i) => (
        <Star key={`filled-${i}`} className="h-5 w-5 fill-current" />
      ))}
      {Array.from({ length: totalStars - filledStars }, (_, i) => (
        <Star key={`empty-${i}`} className="h-5 w-5" />
      ))}
    </div>
  );
}
