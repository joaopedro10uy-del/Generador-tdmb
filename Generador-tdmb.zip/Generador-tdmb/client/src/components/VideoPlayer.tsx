import { useState, useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';

interface VideoPlayerProps {
  url: string;
  season: number;
  episode: number;
}

export function VideoPlayer({ url, season, episode }: VideoPlayerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    setLoading(true);
    setError(false);
    
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, [url, season, episode]);

  const handleError = () => {
    setError(true);
    setLoading(false);
  };

  return (
    <div className="relative aspect-video bg-black rounded-lg overflow-hidden" data-testid="video-player">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-white mx-auto mb-2" />
            <p className="text-sm text-gray-400">Cargando episodio {episode}...</p>
          </div>
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <p className="text-sm text-gray-400">Error al cargar el reproductor</p>
        </div>
      )}

      <iframe
        ref={iframeRef}
        key={`${season}-${episode}-${url}`}
        src={url}
        className="w-full h-full border-0"
        allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
        allowFullScreen
        onLoad={() => setLoading(false)}
        onError={handleError}
        title={`Temporada ${season} Episodio ${episode}`}
        data-testid="iframe-player"
      />
    </div>
  );
}
