import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SeriesGenerator } from '@/components/SeriesGenerator';
import { MovieGenerator } from '@/components/MovieGenerator';
import { Film, Tv, Sparkles } from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState('series');

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-5 md:py-6">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-black font-headline tracking-tight">
            Generador de Contenido
          </h1>
          <p className="text-muted-foreground mt-1.5 sm:mt-2 text-sm sm:text-base">
            Crea páginas HTML profesionales para series, películas y anime con integración TMDB
          </p>
        </div>
      </header>
      <main className="container mx-auto px-3 sm:px-4 md:px-6 pb-6 md:pb-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 md:mb-8 h-auto">
            <TabsTrigger
              value="series"
              className="flex items-center gap-2 py-3"
              data-testid="tab-series"
            >
              <Tv className="h-4 w-4" />
              <span className="hidden sm:inline">Series</span>
            </TabsTrigger>
            <TabsTrigger
              value="movies"
              className="flex items-center gap-2 py-3"
              data-testid="tab-movies"
            >
              <Film className="h-4 w-4" />
              <span className="hidden sm:inline">Películas</span>
            </TabsTrigger>
            <TabsTrigger
              value="anime"
              className="flex items-center gap-2 py-3"
              data-testid="tab-anime"
            >
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Anime</span>
            </TabsTrigger>
          </TabsList>
          <TabsContent value="series">
            <SeriesGenerator />
          </TabsContent>
          <TabsContent value="movies">
            <MovieGenerator />
          </TabsContent>
          <TabsContent value="anime">
            <SeriesGenerator isAnime />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
