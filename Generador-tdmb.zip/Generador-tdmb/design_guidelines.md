# Design Guidelines: TV Series Episode Player Generator

## Design Approach

**Selected Approach:** Reference-Based (Streaming Platforms)  
**Primary References:** Netflix, Disney+, HBO Max player interfaces  
**Justification:** This is a content-focused streaming application where visual presentation of media content is paramount. Drawing from established streaming platforms ensures familiar, battle-tested patterns for video consumption.

## Core Design Principles

1. **Content First:** Series artwork and video player take visual priority
2. **Cinematic Experience:** Dark theme with high contrast for optimal video viewing
3. **Immediate Clarity:** Clear episode/season navigation without confusion
4. **Functional Elegance:** Professional utility interface with polished aesthetics

## Typography System

**Font Families:**
- Headlines: Inter Bold/Black (700-900 weight) for series titles
- UI Elements: Inter Medium (500 weight) for labels and buttons  
- Body Text: Inter Regular (400 weight) for descriptions

**Hierarchy:**
- Series Title: text-4xl to text-5xl, font-black, uppercase tracking
- Section Headers: text-2xl, font-bold
- Form Labels: text-sm, font-medium
- Episode Selectors: text-base, font-medium
- Descriptions: text-base, leading-relaxed

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, and 8 (p-2, p-4, gap-6, mt-8)

**Grid Structure:**
- Two-column desktop layout: Configuration panel (left) | Preview panel (right)
- Mobile: Single column stack
- Use `lg:grid-cols-2` breakpoint for desktop split

**Container Rules:**
- Form sections: max-w-4xl
- Preview area: Full width of column
- Player container: max-w-4xl centered

## Component Library

### Configuration Panel (Left Column)

**Card Structure:**
- White/light background card with subtle shadow
- Padding: p-6
- Border radius: rounded-lg
- Clear visual separation from preview

**Form Elements:**
- Input fields: Full width, rounded-md, clear borders
- Labels: Bold, positioned above inputs with mb-2
- Button (Primary): Full width, prominent color, rounded-md
- Button states: Loading spinner indicator, disabled opacity

**Season/Episode Accordion:**
- Collapsible sections per season
- Clear trigger indicators
- Nested episode inputs with consistent spacing (gap-3)
- Scrollable content area (max-h-60) for many episodes
- Episode number labels: Fixed width (w-20) for alignment

### Preview Panel (Right Column)

**Live Preview Container:**
- Minimum height: min-h-[400px]
- Dark background matching video player aesthetic
- Rounded corners and subtle shadow
- Loading state: Centered spinner
- Empty state: Centered instructional text

**Series Display Layout:**
- Backdrop image: Full bleed with dark gradient overlay
- Two-section layout: Poster + Info (desktop) | Stacked (mobile)
- Poster: Fixed width 280px on desktop, responsive on mobile
- Info section: Flexible width, max-w-2xl

**Series Information:**
- Title: Large, bold, uppercase with letter spacing
- Metadata row: Flex wrap with star rating, year badge, genres
- Star rating: Yellow filled/outline stars (5-star display)
- Year badge: Rounded pill with semi-transparent background
- Synopsis: Readable line height, muted text color

**Action Buttons:**
- Primary "VER AHORA": Large, high contrast (white bg on dark)
- Secondary "TRAILER": Red/accent color, large size
- Icon + Text layout with proper spacing
- Buttons disabled when no content available

**Video Player Section:**
- Dark semi-transparent background (backdrop-blur effect)
- Season/Episode selectors: Side-by-side on desktop, stacked on mobile
- Selectors: Dark background matching player aesthetic, white text
- Player: 16:9 aspect ratio container
- Empty state: Centered message in aspect-ratio container

### Code Display Component

**Structure:**
- Separate section below preview
- Syntax highlighting container
- Copy button functionality
- Rounded borders and proper padding

## Visual Patterns

**Color Strategy (Descriptive):**
- Use dark themes for video-focused areas (player, preview backdrop)
- Use light themes for configuration/form areas
- High contrast for readability
- Accent colors for CTAs and interactive elements

**Elevation & Depth:**
- Cards: Subtle shadows for separation
- Preview area: Deeper shadow for prominence
- Player: Contained within dark section, no additional shadow
- Modal/Dialog: High elevation with backdrop

**States & Feedback:**
- Loading: Spinner animations
- Disabled: Reduced opacity
- Error: Toast notifications
- Empty: Clear instructional messaging

## Responsive Behavior

**Breakpoints:**
- Mobile (base): Single column, stacked layout
- Desktop (lg): Two-column split

**Mobile Optimizations:**
- Poster: Centered, smaller width
- Info: Full width text blocks
- Buttons: Full width stack
- Selectors: Full width, vertical stack
- Accordion: Maintain for episode organization

**Touch Targets:**
- Buttons: Minimum 44px height
- Select dropdowns: Large enough for easy tapping
- Accordion triggers: Full width clickable area

## Accessibility Requirements

- All form inputs: Associated labels with htmlFor
- Select components: Proper ARIA labels
- Disabled states: Clear visual indication
- Dialog: Focus trap and escape key handling
- Video player: Allow fullscreen and controls
- Loading states: Screen reader announcements

## Images

**Series Poster:**
- Placement: Left side of preview panel
- Dimensions: 280x420px (2:3 ratio)
- Style: Rounded corners, shadow effect
- Fallback: Placeholder if unavailable

**Backdrop Image:**
- Placement: Full background of preview section
- Treatment: Dark gradient overlay (left/right fade to black)
- Purpose: Cinematic atmosphere without overwhelming content
- Fallback: Solid dark background

**No Hero Section:** This is a utility application, not a landing page. The preview panel serves as the visual focal point.

## Key Interactions

- Smooth scroll to player when "VER AHORA" clicked
- Season change auto-selects first available episode
- Episode change updates player immediately
- Trailer opens in centered modal overlay
- Form submission shows loading state throughout
- Toast notifications for errors (destructive variant)