# Generador de Contenido para Series, Películas y Anime

## Overview
Aplicación web profesional que genera páginas HTML completas para series de TV, películas y anime con integración TMDB (The Movie Database). Los usuarios pueden seleccionar el tipo de contenido, ingresar un ID de TMDB, configurar URLs de reproducción, y generar páginas HTML standalone con diseño cinematográfico responsivo.

## Recent Changes (November 10, 2025)
### Latest Update - Corrección de Manejo de Errores
- **Mensajes de error mejorados**: IDs inválidos ahora muestran mensajes claros en español
- **Códigos HTTP correctos**: Devuelve 404 cuando un ID no existe en TMDB, 500 para errores del servidor
- **Detección específica de errores**: La aplicación distingue entre IDs no encontrados y otros tipos de errores
- **Mensajes en español**: Todos los errores están traducidos y son fáciles de entender para el usuario

### Previous Update - URL Manual de Tráiler y Mejoras de Responsividad
- **Campo de URL de tráiler manual**: Nuevo input opcional en todos los generadores (Series, Películas, Anime) para proporcionar URL personalizada del tráiler
- **Fallback inteligente**: Si no se proporciona URL manual, se usa automáticamente el tráiler de TMDB
- **Helper CSS compartido**: Nueva función `buildBaseStyles()` para evitar duplicación de código CSS
- **HTML totalmente en español**: Todos los títulos, etiquetas y textos generados ahora están en español
- **Responsividad mejorada**: CSS optimizado con breakpoints móviles, fuentes escalables (1.75rem → 3rem), padding adaptativo (12px → 20px), y botones full-width en móvil

### Previous Update - Sistema de Pestañas y Responsividad
- **Sistema de tres pestañas**: Series, Películas y Anime con navegación fluida
- **Responsividad completa**: Diseño optimizado para móvil, tablet y PC con breakpoints adaptativos
- **Reproductores ocultos**: El reproductor de video solo aparece cuando el usuario presiona "VER AHORA" o "TRÁILER"
- **Generador de películas**: Nuevo componente MovieGenerator con endpoint /api/movie/generate
- **Validación Zod**: Request body validation implementada en todos los endpoints
- **Mejoras de UX**: Botones full-width en móvil, espaciado responsivo, fuentes escalonadas

### Previous Updates
- Complete application refactor and improvement with modern tech stack
- Implemented TMDB API integration for automatic series metadata fetching
- Built responsive, cinema-quality UI following streaming platform design patterns
- Added video player with smooth loading states and episode navigation
- Implemented HTML code generation with copy-to-clipboard functionality
- Fixed critical routing and data parsing bugs
- Added comprehensive error handling and user feedback

## Project Architecture

### Frontend
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight routing)
- **State Management**: TanStack Query v5 for server state
- **Styling**: Tailwind CSS with custom design tokens and responsive breakpoints
- **Component Library**: Shadcn UI (Radix UI primitives) with Tabs, Dialog, Accordion
- **Icons**: Lucide React (Tv, Film, Sparkles, PlayCircle)

### Backend
- **Framework**: Express.js with TypeScript
- **API Integration**: TMDB API v3 (TV shows, movies, trailers, metadata)
- **Validation**: Zod schemas for type-safe request/response handling
- **Server**: Node.js with hot reload via tsx

### Key Features
1. **Three Content Types**: Separate sections for Series, Movies, and Anime
2. **Series Lookup**: Automatic season/episode fetching from TMDB
3. **Movie Support**: Single-page movie player with TMDB integration
4. **Episode Configuration**: Accordion-based UI for entering episode streaming URLs
5. **Live Preview**: Real-time preview of content page with poster, backdrop, ratings, and player
6. **Hidden Players**: Video players only appear after user interaction ("VER AHORA" button)
7. **Trailer Support**: Modal trailer viewer with YouTube integration
8. **HTML Generation**: Complete standalone HTML page generation for series and movies
9. **Code Export**: Copy-to-clipboard functionality for generated HTML
10. **Responsive Design**: Optimized layouts for mobile (320px+), tablet (768px+), and desktop (1024px+)

## User Preferences
- Language: Spanish (UI text in Spanish)
- Design Style: Dark, cinematic theme inspired by Netflix/Disney+/HBO Max
- Typography: Inter font family (400-900 weights)
- Color Scheme: High contrast dark theme for video content, light theme for configuration
- Responsiveness: Mobile-first approach with fluid breakpoints

## File Structure

### Core Application Files
- `client/src/App.tsx` - Main app component with routing
- `client/src/pages/Home.tsx` - Homepage with tabbed interface (Series/Movies/Anime)
- `client/src/components/SeriesGenerator.tsx` - Series/Anime form and logic (supports isAnime prop)
- `client/src/components/MovieGenerator.tsx` - Movie form and logic
- `client/src/components/SeriesPreview.tsx` - Series preview with hidden player until interaction
- `client/src/components/MoviePreview.tsx` - Movie preview with hidden player until interaction
- `client/src/components/VideoPlayer.tsx` - Video iframe with loading states
- `client/src/components/CodeDisplay.tsx` - HTML code display with copy
- `client/src/components/StarRating.tsx` - Star rating visualization
- `shared/schema.ts` - TypeScript types and Zod validation schemas (series, movies, content types)
- `server/routes.ts` - API routes for TMDB integration and HTML generation

### Configuration
- `tailwind.config.ts` - Custom design tokens (Inter font, spacing, colors, responsive breakpoints)
- `client/index.html` - HTML template with Inter font CDN
- `design_guidelines.md` - Comprehensive UI/UX design specifications

## API Endpoints

### GET /api/series/seasons/:seriesId
Fetches season information for a TV series from TMDB.
- **Path Parameter**: `seriesId` (TMDB series ID)
- **Response**: `{ seasons: SeasonData[] }` or `{ error: string }`
- **Status Codes**: 200 (success), 400 (invalid ID), 500 (TMDB error)

### POST /api/series/generate
Generates complete HTML player page for a series.
- **Body**: `{ seriesId: string, episodes: EpisodeUrl[] }`
- **Validation**: Zod schema `generateSeriesHtmlRequestSchema`
- **Response**: `{ html: string, seriesData: SeriesData, seasons: SeasonData[], trailerUrl: string }`
- **Status Codes**: 200 (success), 400 (invalid data), 500 (generation error)

### POST /api/movie/generate
Generates complete HTML player page for a movie.
- **Body**: `{ movieId: string, movieUrl: string }`
- **Validation**: Zod schema `generateMovieHtmlRequestSchema`
- **Response**: `{ html: string, movieData: MovieData, trailerUrl: string }`
- **Status Codes**: 200 (success), 400 (invalid data), 500 (generation error)

## Environment Variables
- `TMDB_API_KEY` - API key for The Movie Database (required)
- `SESSION_SECRET` - Session secret for Express (pre-configured)

## Responsive Design Breakpoints
- **Mobile**: 320px - 639px (sm breakpoint)
  - Single column layout
  - Full-width buttons
  - Stacked poster and info
  - Smaller font sizes (text-2xl for titles)
- **Tablet**: 640px - 1023px (md breakpoint)
  - Two-column grid for form/preview
  - Side-by-side poster and info
  - Medium font sizes (text-3xl/4xl for titles)
- **Desktop**: 1024px+ (lg breakpoint)
  - Optimized spacing (gap-8, p-8)
  - Large font sizes (text-5xl for titles)
  - Wide layouts with max-width containers

## Testing
- End-to-end testing completed with Playwright
- All user journeys tested: 
  - Series lookup → episode configuration → HTML generation → playback
  - Movie lookup → URL input → HTML generation → playback
  - Tab switching between Series/Movies/Anime
  - Hidden player behavior (appears only after "VER AHORA" click)
- Known minor issues: TrustedHTML console warnings (non-blocking)

## How to Use

### For Series/Anime
1. Navigate to "Series" or "Anime" tab
2. Enter a TMDB Series ID (e.g., "1399" for Game of Thrones, "37854" for One Piece)
3. Wait for seasons to load automatically
4. Expand seasons and enter episode streaming URLs
5. Click "Generar Código" to generate the HTML page
6. Click "VER AHORA" to reveal and play the video
7. Preview the series page in real-time
8. Copy the generated HTML code to use on your own website

### For Movies
1. Navigate to "Películas" tab
2. Enter a TMDB Movie ID (e.g., "550" for Fight Club)
3. Enter the movie streaming URL
4. Click "Generar Código" to generate the HTML page
5. Click "VER AHORA" to reveal and play the video
6. Preview the movie page in real-time
7. Copy the generated HTML code to use on your own website

## Next Steps / Future Enhancements
- Episode progress tracking and resume watching functionality with localStorage
- Keyboard shortcuts for video playback (space, arrow keys, fullscreen)
- Bulk episode URL import (CSV/JSON file upload)
- Episode thumbnails and metadata display with TMDB integration
- Search and filter functionality for series and episodes
- Dark/light mode toggle (currently dark theme only)
