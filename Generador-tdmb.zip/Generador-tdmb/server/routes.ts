import type { Express } from "express";
import { createServer, type Server } from "http";
import {
  getSeasonsRequestSchema,
  generateSeriesHtmlRequestSchema,
  generateMovieHtmlRequestSchema,
  type GetSeasonsResponse,
  type GenerateSeriesHtmlResponse,
  type SeriesData,
  type SeasonData,
} from "@shared/schema";

const TMDB_API_KEY = process.env.TMDB_API_KEY;
const TMDB_BASE_URL = "https://api.themoviedb.org/3";
const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";

async function fetchTMDB(endpoint: string) {
  const url = `${TMDB_BASE_URL}${endpoint}${endpoint.includes('?') ? '&' : '?'}api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 404) {
      throw new Error(`ID no encontrado en TMDB`);
    }
    throw new Error(`Error de TMDB API: ${response.statusText}`);
  }
  return response.json();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get series seasons
  app.get("/api/series/seasons/:seriesId", async (req, res) => {
    try {
      const { seriesId } = req.params;
      
      if (!seriesId || seriesId.trim() === '') {
        return res.status(400).json({ error: "ID de serie inválido" } as GetSeasonsResponse);
      }

      const seriesData = await fetchTMDB(`/tv/${seriesId}`);
      
      const seasons: SeasonData[] = seriesData.seasons
        .filter((s: any) => s.season_number > 0) // Filter out specials (season 0)
        .map((s: any) => ({
          season_number: s.season_number,
          episode_count: s.episode_count,
        }));

      res.status(200).json({ seasons } as GetSeasonsResponse);
    } catch (error: any) {
      console.error("Error fetching seasons:", error);
      const isNotFound = error.message?.includes("ID no encontrado");
      const errorMessage = isNotFound
        ? "ID de serie no encontrado en TMDB. Verifica que el ID sea correcto."
        : "Error al obtener temporadas. Verifica el ID de la serie.";
      res.status(isNotFound ? 404 : 500).json({ 
        error: errorMessage
      } as GetSeasonsResponse);
    }
  });

  // Generate series HTML
  app.post("/api/series/generate", async (req, res) => {
    try {
      const parseResult = generateSeriesHtmlRequestSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Datos de solicitud inválidos" 
        } as GenerateSeriesHtmlResponse);
      }

      const { seriesId, episodes, trailerUrl: manualTrailerUrl } = parseResult.data;

      // Fetch series details
      const seriesData = await fetchTMDB(`/tv/${seriesId}`);
      
      // Fetch videos (trailers)
      const videosData = await fetchTMDB(`/tv/${seriesId}/videos`);
      const trailer = videosData.results?.find(
        (v: any) => v.type === "Trailer" && v.site === "YouTube"
      );

      const genres = seriesData.genres.map((g: any) => g.name).join(", ");
      const year = seriesData.first_air_date?.split("-")[0] || "N/A";
      const posterUrl = seriesData.poster_path
        ? `${TMDB_IMAGE_BASE}/w500${seriesData.poster_path}`
        : "";
      const backdropUrl = seriesData.backdrop_path
        ? `${TMDB_IMAGE_BASE}/original${seriesData.backdrop_path}`
        : "";

      const series: SeriesData = {
        title: seriesData.name,
        posterUrl,
        genres,
        year,
        rating: seriesData.vote_average || 0,
        synopsis: seriesData.overview || "Sin descripción disponible",
        backdropUrl,
        numberOfSeasons: seriesData.number_of_seasons || 0,
      };

      const seasons: SeasonData[] = seriesData.seasons
        .filter((s: any) => s.season_number > 0)
        .map((s: any) => ({
          season_number: s.season_number,
          episode_count: s.episode_count,
        }));

      const trailerUrl = manualTrailerUrl && manualTrailerUrl.trim() 
        ? manualTrailerUrl.trim()
        : trailer
        ? `https://www.youtube.com/embed/${trailer.key}`
        : "";

      // Generate HTML
      const html = generateHTML(series, seasons, episodes, trailerUrl);

      res.status(200).json({
        html,
        seriesData: series,
        seasons,
        trailerUrl,
      } as GenerateSeriesHtmlResponse);
    } catch (error: any) {
      console.error("Error generating HTML:", error);
      const isNotFound = error.message?.includes("ID no encontrado");
      const errorMessage = isNotFound
        ? "ID de serie no encontrado en TMDB. Verifica que el ID sea correcto."
        : "Error al generar el código HTML. Verifica los datos.";
      res.status(isNotFound ? 404 : 500).json({ 
        error: errorMessage
      } as GenerateSeriesHtmlResponse);
    }
  });

  // Generate movie HTML
  app.post("/api/movie/generate", async (req, res) => {
    try {
      const validation = generateMovieHtmlRequestSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Datos de película inválidos" 
        });
      }
      
      const { movieId, movieUrl, trailerUrl: manualTrailerUrl } = validation.data;

      // Fetch movie details
      const movieData = await fetchTMDB(`/movie/${movieId}`);
      
      // Fetch videos (trailers)
      const videosData = await fetchTMDB(`/movie/${movieId}/videos`);
      const trailer = videosData.results?.find(
        (v: any) => v.type === "Trailer" && v.site === "YouTube"
      );

      const genres = movieData.genres.map((g: any) => g.name).join(", ");
      const year = movieData.release_date?.split("-")[0] || "N/A";
      const posterUrl = movieData.poster_path
        ? `${TMDB_IMAGE_BASE}/w500${movieData.poster_path}`
        : "";
      const backdropUrl = movieData.backdrop_path
        ? `${TMDB_IMAGE_BASE}/original${movieData.backdrop_path}`
        : "";

      const movie = {
        title: movieData.title,
        posterUrl,
        genres,
        year,
        rating: movieData.vote_average || 0,
        synopsis: movieData.overview || "Sin descripción disponible",
        backdropUrl,
      };

      const trailerUrl = manualTrailerUrl && manualTrailerUrl.trim()
        ? manualTrailerUrl.trim()
        : trailer
        ? `https://www.youtube.com/embed/${trailer.key}`
        : "";

      // Generate HTML for movie
      const html = generateMovieHTML(movie, movieUrl, trailerUrl);

      res.status(200).json({
        html,
        movieData: movie,
        trailerUrl,
      });
    } catch (error: any) {
      console.error("Error generating movie HTML:", error);
      const isNotFound = error.message?.includes("ID no encontrado");
      const errorMessage = isNotFound
        ? "ID de película no encontrado en TMDB. Verifica que el ID sea correcto."
        : "Error al generar el código HTML. Verifica los datos.";
      res.status(isNotFound ? 404 : 500).json({ 
        error: errorMessage
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function buildBaseStyles(): string {
  return `
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #000;
            color: #fff;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 12px;
        }
        @media (min-width: 768px) {
            .container { padding: 20px; }
        }
        .hero {
            position: relative;
            background-size: cover;
            background-position: center;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        @media (min-width: 768px) {
            .hero { margin-bottom: 40px; }
        }
        .hero-content {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
            align-items: center;
        }
        @media (min-width: 768px) {
            .hero-content {
                gap: 30px;
                padding: 40px;
            }
        }
        .poster {
            width: 100%;
            max-width: 180px;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        @media (min-width: 768px) {
            .poster { max-width: 280px; }
        }
        .info {
            flex: 1;
            min-width: 250px;
            max-width: 700px;
        }
        .title {
            font-size: 1.75rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 15px;
            line-height: 1.2;
        }
        @media (min-width: 768px) {
            .title { font-size: 3rem; margin-bottom: 20px; }
        }
        .metadata {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
            margin-bottom: 15px;
            font-size: 0.85rem;
        }
        @media (min-width: 768px) {
            .metadata { gap: 15px; margin-bottom: 20px; font-size: 0.9rem; }
        }
        .rating {
            color: #fbbf24;
            font-weight: bold;
        }
        .year {
            background: rgba(255,255,255,0.15);
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: bold;
        }
        @media (min-width: 768px) {
            .year { padding: 5px 15px; }
        }
        .synopsis {
            line-height: 1.6;
            margin-bottom: 20px;
            color: #e5e7eb;
            font-size: 0.9rem;
        }
        @media (min-width: 768px) {
            .synopsis { line-height: 1.7; margin-bottom: 30px; font-size: 1rem; }
        }
        .buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        @media (min-width: 768px) {
            .buttons { gap: 15px; }
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: bold;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            width: 100%;
            justify-content: center;
        }
        @media (min-width: 640px) {
            .btn { width: auto; padding: 12px 30px; font-size: 1rem; }
        }
        .btn-primary {
            background: #fff;
            color: #000;
        }
        .btn-primary:hover {
            background: #e5e5e5;
        }
        .btn-secondary {
            background: #ef4444;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #dc2626;
        }
        .player-section {
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
        }
        @media (min-width: 768px) {
            .player-section { padding: 30px; margin-top: 40px; }
        }
        .video-container {
            position: relative;
            width: 100%;
            padding-bottom: 56.25%;
            background: #000;
            border-radius: 8px;
            overflow: hidden;
        }
        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal.active {
            display: flex;
        }
        .modal-content {
            max-width: 1200px;
            width: 100%;
            aspect-ratio: 16/9;
        }
        .modal-content iframe {
            width: 100%;
            height: 100%;
            border-radius: 8px;
        }
        .close-modal {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 2rem;
            color: #fff;
            cursor: pointer;
            z-index: 1001;
            background: rgba(0,0,0,0.5);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        @media (min-width: 768px) {
            .close-modal { top: 20px; right: 30px; }
        }`;
}

function generateMovieHTML(
  movie: any,
  movieUrl: string,
  trailerUrl: string
): string {
  return `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${movie.title} - Reproductor de Película</title>
    <style>${buildBaseStyles()}
        .hero {
            background-image: linear-gradient(to right, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0.85) 100%), url('${movie.backdropUrl}');
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="hero">
            <div class="hero-content">
                <img src="${movie.posterUrl}" alt="${movie.title}" class="poster">
                <div class="info">
                    <h1 class="title">${movie.title}</h1>
                    <div class="metadata">
                        <span class="rating">⭐ ${movie.rating.toFixed(1)}</span>
                        <span class="year">${movie.year}</span>
                        <span>${movie.genres}</span>
                    </div>
                    <p class="synopsis">${movie.synopsis}</p>
                    <div class="buttons">
                        <button class="btn btn-primary" onclick="scrollToPlayer()">▶ VER AHORA</button>
                        ${trailerUrl ? `<button class="btn btn-secondary" onclick="openTrailer()">▶ TRÁILER</button>` : ''}
                    </div>
                </div>
            </div>
        </div>

        <div class="player-section" id="player">
            <div class="video-container">
                <iframe src="${movieUrl}" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>
            </div>
        </div>
    </div>

    <div class="modal" id="trailerModal">
        <span class="close-modal" onclick="closeTrailer()">&times;</span>
        <div class="modal-content">
            <iframe src="${trailerUrl}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
    </div>

    <script>
        function scrollToPlayer() {
            document.getElementById('player').scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function openTrailer() {
            document.getElementById('trailerModal').classList.add('active');
        }

        function closeTrailer() {
            document.getElementById('trailerModal').classList.remove('active');
        }
    </script>
</body>
</html>`;
}

function generateHTML(
  series: SeriesData,
  seasons: SeasonData[],
  episodes: any[],
  trailerUrl: string
): string {
  const episodesJSON = JSON.stringify(episodes);
  const seasonsJSON = JSON.stringify(seasons);

  return `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${series.title} - Reproductor de Series</title>
    <style>${buildBaseStyles()}
        .hero {
            background-image: linear-gradient(to right, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0.85) 100%), url('${series.backdropUrl}');
        }
        .controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        @media (min-width: 768px) {
            .controls { gap: 20px; }
        }
        .control-group {
            flex: 1;
            min-width: 150px;
        }
        .control-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 0.9rem;
        }
        @media (min-width: 768px) {
            .control-group { min-width: 200px; }
        }
        .control-group select {
            width: 100%;
            padding: 10px;
            background: #1f2937;
            border: 1px solid #374151;
            border-radius: 6px;
            color: #fff;
            font-size: 0.9rem;
        }
        @media (min-width: 768px) {
            .control-group select { padding: 12px; font-size: 1rem; }
        }
        .empty-state {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #6b7280;
            font-size: 0.9rem;
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="hero">
            <div class="hero-content">
                <img src="${series.posterUrl}" alt="${series.title}" class="poster">
                <div class="info">
                    <h1 class="title">${series.title}</h1>
                    <div class="metadata">
                        <span class="rating">⭐ ${series.rating.toFixed(1)}</span>
                        <span class="year">${series.year}</span>
                        <span>${series.genres}</span>
                    </div>
                    <p class="synopsis">${series.synopsis}</p>
                    <div class="buttons">
                        <button class="btn btn-primary" onclick="scrollToPlayer()">▶ VER AHORA</button>
                        ${trailerUrl ? `<button class="btn btn-secondary" onclick="openTrailer()">▶ TRÁILER</button>` : ''}
                    </div>
                </div>
            </div>
        </div>

        <div class="player-section" id="player">
            <div class="controls">
                <div class="control-group">
                    <label for="season">Temporada</label>
                    <select id="season" onchange="onSeasonChange()"></select>
                </div>
                <div class="control-group">
                    <label for="episode">Episodio</label>
                    <select id="episode" onchange="onEpisodeChange()"></select>
                </div>
            </div>
            <div class="video-container" id="videoContainer">
                <div class="empty-state">Seleccione un episodio para reproducir</div>
            </div>
        </div>
    </div>

    <div class="modal" id="trailerModal">
        <span class="close-modal" onclick="closeTrailer()">&times;</span>
        <div class="modal-content">
            <iframe src="${trailerUrl}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
    </div>

    <script>
        const episodes = ${episodesJSON};
        const seasons = ${seasonsJSON};
        let currentSeason = null;
        let currentEpisode = null;

        function init() {
            const availableSeasons = [...new Set(episodes.map(e => e.season))].sort((a,b) => a-b);
            const seasonSelect = document.getElementById('season');
            
            availableSeasons.forEach(s => {
                const option = document.createElement('option');
                option.value = s;
                option.textContent = 'Temporada ' + s;
                seasonSelect.appendChild(option);
            });

            if (availableSeasons.length > 0) {
                currentSeason = availableSeasons[0];
                seasonSelect.value = currentSeason;
                updateEpisodes();
            }
        }

        function updateEpisodes() {
            const episodeSelect = document.getElementById('episode');
            episodeSelect.innerHTML = '';
            
            const seasonEpisodes = episodes.filter(e => e.season === currentSeason).sort((a,b) => a.episode - b.episode);
            
            seasonEpisodes.forEach(e => {
                const option = document.createElement('option');
                option.value = e.episode;
                option.textContent = 'Episodio ' + e.episode;
                episodeSelect.appendChild(option);
            });

            if (seasonEpisodes.length > 0) {
                currentEpisode = seasonEpisodes[0].episode;
                episodeSelect.value = currentEpisode;
                loadVideo();
            }
        }

        function onSeasonChange() {
            currentSeason = parseInt(document.getElementById('season').value);
            updateEpisodes();
        }

        function onEpisodeChange() {
            currentEpisode = parseInt(document.getElementById('episode').value);
            loadVideo();
        }

        function loadVideo() {
            const ep = episodes.find(e => e.season === currentSeason && e.episode === currentEpisode);
            const container = document.getElementById('videoContainer');
            
            if (ep && ep.url) {
                container.innerHTML = '<iframe src="' + ep.url + '" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>';
            } else {
                container.innerHTML = '<div class="empty-state">Episodio no disponible</div>';
            }
        }

        function scrollToPlayer() {
            document.getElementById('player').scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function openTrailer() {
            document.getElementById('trailerModal').classList.add('active');
        }

        function closeTrailer() {
            document.getElementById('trailerModal').classList.remove('active');
        }

        init();
    </script>
</body>
</html>`;
}
