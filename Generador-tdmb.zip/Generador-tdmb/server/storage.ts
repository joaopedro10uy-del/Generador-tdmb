// Storage interface for future expansion
// Currently not used by the series generator application

export interface IStorage {
  // Add methods here as needed
}

export class MemStorage implements IStorage {
  constructor() {
    // Initialize storage if needed
  }
}

export const storage = new MemStorage();
