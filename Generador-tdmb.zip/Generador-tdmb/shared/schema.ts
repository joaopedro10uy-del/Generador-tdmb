import { z } from "zod";

// Content types
export const contentTypeSchema = z.enum(['series', 'movie', 'anime']);
export type ContentType = z.infer<typeof contentTypeSchema>;

// Series/Movie Data Models
export const movieDataSchema = z.object({
  title: z.string(),
  posterUrl: z.string(),
  genres: z.string(),
  year: z.string(),
  rating: z.number(),
  synopsis: z.string(),
  backdropUrl: z.string().optional(),
});

export const seriesDataSchema = movieDataSchema.extend({
  numberOfSeasons: z.number(),
});

export const seasonDataSchema = z.object({
  season_number: z.number(),
  episode_count: z.number(),
});

export const episodeUrlSchema = z.object({
  season: z.number(),
  episode: z.number(),
  url: z.string(),
});

export const playerUrlSchema = z.object({
  url: z.string(),
});

// Request/Response schemas for API
export const getSeasonsRequestSchema = z.object({
  seriesId: z.string(),
});

export const getSeasonsResponseSchema = z.object({
  seasons: z.array(seasonDataSchema).optional(),
  error: z.string().optional(),
});

export const generateSeriesHtmlRequestSchema = z.object({
  seriesId: z.string(),
  episodes: z.array(episodeUrlSchema),
  contentType: contentTypeSchema.optional(),
  trailerUrl: z.string().optional(),
});

export const generateSeriesHtmlResponseSchema = z.object({
  html: z.string().optional(),
  seriesData: seriesDataSchema.optional(),
  movieData: movieDataSchema.optional(),
  seasons: z.array(seasonDataSchema).optional(),
  trailerUrl: z.string().optional(),
  error: z.string().optional(),
});

export const generateMovieHtmlRequestSchema = z.object({
  movieId: z.string(),
  movieUrl: z.string(),
  trailerUrl: z.string().optional(),
});

export const generateMovieHtmlResponseSchema = z.object({
  html: z.string().optional(),
  movieData: movieDataSchema.optional(),
  trailerUrl: z.string().optional(),
  error: z.string().optional(),
});

// TypeScript types
export type MovieData = z.infer<typeof movieDataSchema>;
export type SeriesData = z.infer<typeof seriesDataSchema>;
export type SeasonData = z.infer<typeof seasonDataSchema>;
export type EpisodeUrl = z.infer<typeof episodeUrlSchema>;
export type PlayerUrl = z.infer<typeof playerUrlSchema>;
export type GetSeasonsRequest = z.infer<typeof getSeasonsRequestSchema>;
export type GetSeasonsResponse = z.infer<typeof getSeasonsResponseSchema>;
export type GenerateSeriesHtmlRequest = z.infer<typeof generateSeriesHtmlRequestSchema>;
export type GenerateSeriesHtmlResponse = z.infer<typeof generateSeriesHtmlResponseSchema>;
export type GenerateMovieHtmlRequest = z.infer<typeof generateMovieHtmlRequestSchema>;
export type GenerateMovieHtmlResponse = z.infer<typeof generateMovieHtmlResponseSchema>;
